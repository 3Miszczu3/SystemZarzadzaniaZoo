<div class="specials-section">
					<div class="container">
						<div class="specials-grids">
							
							<div class="col-md-4 specials1">
								<h3>Szczegóły</h3>
								<ul>
									<li><a href="about.php">O Nas</a></li>
									<li><a href="index.php">Strona</a></li>
									<li><a href="contact.php">Kontakt</a></li>
									<li><a href="admin/index.php">Panel Sterowania</a></li>
								</ul>
							</div>
							<div class="col-md-4 specials1">
								<h3>Kontakt</h3>
								<?php 
 $query=mysqli_query($con,"select * from  tblpage where PageType='contactus'");
 while ($row=mysqli_fetch_array($query)) {
 ?>
								<address>
									<p>Email : <?php  echo $row['Email'];?></p>
								 <p>Nr Telefonu : <?php  echo $row['MobileNumber'];?></p>
								 <p><?php  echo $row['PageDescription'];?></p>
								</address><?php } ?>
							</div>
							<div class="col-md-4 specials1">
								<h3>Media Społecznościowe</h3>
								<ul>
									<li><a href="http://zsegw.pl">facebook</a></li>
									<li><a href="http://zsegw.pl">twitter</a></li>
									<li><a href="http://zsegw.pl">patreon</a></li>

								</ul>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
