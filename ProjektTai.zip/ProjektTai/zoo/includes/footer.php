<div class="footer-section">
				<div class="container">
					<div class="footer-top">
						<p>&copy; <?php echo date('Y')?> System Zarządzania Zoo </p>
					</div>
				</div>
			</div>
		