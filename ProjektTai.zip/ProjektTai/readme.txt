Jakub Rybka kl 4TD
Stworzyć bazę danych o naziwe zmsdb i następnie zimportować plik.
Strona zrobiona tylko częściowa przezemnie (nie ma co oszukiwać to widać). Moja część to:
Połączenie z bazą danych, stworzenie layout-u, większośc style.css, baza danych. Reszta to rzeczy znalezione na youtubie, githubie oraz stackoverflow tak więc część strony po logowaniu nie jest moja (chodzi o dodawanie i zarządzanie zwierzętami).
Dane do logowania:
admin
Test@123
